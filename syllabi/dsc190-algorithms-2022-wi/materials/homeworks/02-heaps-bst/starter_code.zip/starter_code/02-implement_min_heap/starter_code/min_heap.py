

class MinHeap:

    def __init__(self):
        ...

    def insert(self, key):
        """Insert a key into the heap."""
        ...

    def min(self):
        """Return, but do not remove the minimum. If the heap is empty,
        NaN is returned.

        Example
        -------
        >>> h = MinHeap()
        >>> h.min()
        nan
        >>> h.insert(40)
        >>> h.insert(-3.14)
        >>> h.insert(20)
        >>> h.min()
        -3.14

        """
        ...

    def decrease_key(self, ix, key):
        """Decrease the value of element i's key.

        Parameters
        ----------
        ix : int
            The index of the element whose key will be decreased.
        key
            The element's new key. This should be <= the old key.

        Raises
        ------
        ValueError
            If the element's new key is not <= the old key.

        Example
        -------
        >>> h = MinHeap()
        >>> h.insert(10)
        >>> h.insert(20)
        >>> h.insert(30) # this is element 2
        >>> h.decrease_key(2, 5)
        >>> h.min()
        5

        """
        ...

    def pop_min_key(self):
        """Remove and return the minimum key.

        Raises
        ------
        IndexError
            If the heap is empty.

        Examples
        --------
        >>> h = MinHeap()
        >>> h.insert(30)
        >>> h.insert(10)
        >>> h.insert(20)
        >>> h.pop_min_key()
        10
        >>> h.pop_min_key()
        20
        >>> h.pop_min_key()
        30
        >>> h.pop_min_key()
        Traceback (most recent call last):
        ...
        IndexError: Heap is empty.


        """
        ...
