class Node:
    """A node in a BinarySearchTree. Has a key."""

    def __init__(self, key, parent=None):
        self.key = key
        self.parent = parent
        self.left = None
        self.right = None


class BinarySearchTree:
    def __init__(self):
        self.root = None

    def _right_rotate(self, x: Node):
        """Rotates a node down to the right.

        Parameters
        ----------
        x : Node
            A node in the tree.

        """
        if x is None:
            return

        u = x.left
        B = u.right
        C = x.right
        p = x.parent

        x.left = B
        if B is not None:
            B.parent = x

        u.right = x
        x.parent = u

        u.parent = p

        if p is None:
            self.root = u
        elif p.left is x:
            p.left = u
        else:
            p.right = u

    def _left_rotate(self, x: Node):
        """Rotates a node down to the left.

        Parameters
        ----------
        x : Node
            A node in the tree.

        """
        ...

    def insert(self, new_key) -> Node:
        """Inserts a new key into the BST.

        Parameters
        ----------
        new_key
            A node with this key will be created.

        Returns
        -------
        Node
            The created node, in case you'd like to hang on to it.

        """
        ...

    def query(self, target) -> Node:
        """Check whether a node exists with the given target key.

        Parameters
        ----------
        target
            The key to search for.

        Returns
        -------
        Node
            If the target is in the BST, a node with the target key is returned.
            If two nodes in the BST have the target key, either may be returned.
            If the target is not in the BST, a ValueError should be raised.

        Raises
        ------
        ValueError
            If there is no node in the BST with the target key.

        """
        current_node = self.root
        while current_node is not None:
            if current_node.key == target:
                return current_node
            elif current_node.key < target:
                current_node = current_node.right
            else:
                current_node = current_node.left
        raise ValueError("Key not in BST.")

    def floor(self, target) -> Node:
        """Find the node with the largest key <= target.

        Parameters
        ----------
        target
            The key to look for.

        Returns
        -------
        Node
            A node in the BST with the largest key that is <= target.

        Raises
        ------
        ValueError
            If there is no node in the BST with a key <= target.

        Example
        -------

        >>> bst = BinarySearchTree()
        >>> _ = bst.insert(10)
        >>> _ = bst.insert(20)
        >>> _ = bst.insert(30)
        >>> bst.floor(42).key
        30
        >>> bst.floor(20).key
        20
        >>> bst.floor(5)
        Traceback (most recent call last):
         ...
        ValueError: 5 has no floor.

        """
        ...

    def ceil(self, target) -> Node:
        """Find the node with the smallest key >= target.

        Parameters
        ----------
        target
            The key to look for.

        Returns
        -------
        Node
            A node in the BST with the largest key that is <= target.

        Raises
        ------
        ValueError
            If there is no node in the BST with a key <= target.

        Example
        -------

        >>> bst = BinarySearchTree()
        >>> _ = bst.insert(10)
        >>> _ = bst.insert(20)
        >>> _ = bst.insert(30)
        >>> bst.ceil(5).key
        10
        >>> bst.ceil(20).key
        20
        >>> bst.ceil(42)
        Traceback (most recent call last):
         ...
        ValueError: 42 has no ceiling.

        """
        ...

    def delete(self, x: Node):
        """Remove the node from the BST.

        Note that you must specify the Node, and not the key. This is more
        efficient, because specifying the key would require a query to find the
        node. If you want to delete a specific key, use .query to find the node
        first, then use this method.

        Parameters
        ----------
        x : Node
            A node in the BST. We will assume that x is indeed in the BST.

        Example
        -------

        >>> bst = BinarySearchTree()
        >>> n1 = bst.insert(10)
        >>> n2 = bst.insert(-20)
        >>> n3 = bst.insert(3.14)
        >>> bst.query(3.14) == n3
        True
        >>> bst.delete(n3)
        >>> # the next line should raise a ValueError, because .query raises
        >>> # one if the key is not in the BST
        >>> bst.query(3.14)
        Traceback (most recent call last):
         ...
        ValueError: Key not in BST.

        """
        ...


