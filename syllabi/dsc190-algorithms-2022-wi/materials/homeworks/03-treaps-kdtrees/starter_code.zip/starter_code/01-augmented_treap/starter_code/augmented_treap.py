class TreapNode:
    """A node in a treap.

    Attributes
    ----------
    key
        The node's key, used to place it in the BST.
    priority
        Node's priority, use to place it in the heap.
    size : int
        The number of nodes in subtree rooted at this node.
    parent : Optional[TreapNode]
        The node's parent. If this is a root node, this is None.
    left : Optional[TreapNode]
        The node's left child; if there is none, this is None.
    right : Optional[TreapNode]
        The node's right child; if there is non, this is None.

    """

    def __init__(self, key, priority):
        ...

    def __repr__(self):
        """Nicely displays the node."""
        return f'{self.__class__.__name__}(key={self.key}, priority={self.priority})'


class AugmentedTreap:
    """Half heap, half binary search tree. It's a treap!"""

    def __init__(self):
        """Create an empty treap."""
        ...

    def delete(self, x: TreapNode):
        """Delete the node from the treap.

        Parameters
        ----------
        x : TreapNode
            The node to delete. Note that this is a TreapNode object,
            not a key. If you wish to delete a node with a specific
            key, you should query to find its node.

        Example
        -------
        >>> treap = AugmentedTreap()
        >>> _ = treap.insert(1, 2)
        >>> _ = treap.insert(5, 3)
        >>> n = treap.insert(10, -3)
        >>> treap.query(10) is n
        True
        >>> treap.delete(n)
        >>> treap.query(10) is None # .query() returns None if key not in treap
        True
        """
        ...

    def query(self, target):
        """Return the TreapNode with the specific key.

        Parameters
        ----------
        target
            The key to look for.

        Returns
        -------
        TreapNode or None
            The node with the specific key. Assumes that keys are unique.
            If the they key is not in the treap, return None.

        Example
        -------
        >>> treap = AugmentedTreap()
        >>> treap.insert(1, 10)
        TreapNode(key=1, priority=10)
        >>> treap.insert(5, 12)
        TreapNode(key=5, priority=12)
        >>> treap.query(5)
        TreapNode(key=5, priority=12)
        >>> treap.query(823729183721893721937) is None # key not in treap
        True

        """
        ...

    def insert(self, key, priority):
        """Create a new node with given key and priority.

        Parameters
        ----------
        new_key
            The node's new key. Should be unique.
        new_priority
            The node's priority. Need not be unique.

        Returns
        -------
        TreapNode
            The new node.

        Raises
        ------
        ValueError
            If the new node's key is already in the treap.

        Example
        -------
        >>> treap = AugmentedTreap()
        >>> treap.insert(99, 100)
        TreapNode(key=99, priority=100)
        >>> _ = treap.insert(40, 2)
        >>> _ = treap.insert(99, -4)
        Traceback (most recent call last):
        ...
        ValueError: Duplicate key "99" not allowed.

        """
        ...

    def query_order_statistic(self, k: int):
        """Return the node whose key is kth in the sorted order of keys.

        Parameters
        ----------
        k : int
            The order statistic to return. Note that k=1 is the minimum (we
            start counting from one instead of zero).

        Returns
        -------
        TreapNode
            The treap node whose key appears kth in the ordering.

        Raises
        ------
        ValueError
            If the kth order statistic doesn't exist because k is larger than
            the number of elements in the tree.

        Example
        -------
        >>> treap = AugmentedTreap()
        >>> treap.insert(1, 20)
        TreapNode(key=1, priority=20)
        >>> treap.insert(99, 10)
        TreapNode(key=99, priority=10)
        >>> treap.insert(50, 7)
        TreapNode(key=50, priority=7)
        >>> treap.query_order_statistic(1)
        TreapNode(key=1, priority=20)
        >>> treap.query_order_statistic(2)
        TreapNode(key=50, priority=7)
        >>> treap.query_order_statistic(1000)
        Traceback (most recent call last):
        ...
        ValueError: Order statistic query out of bounds.

        """
        ...

    def __len__(self):
        """Return the number of keys stored in the treap.

        Example
        -------
        >>> treap = AugmentedTreap()
        >>> len(treap)
        0
        >>> _ = treap.insert(-30, 30)
        >>> len(treap)
        1
        """
        ...
