"""A KD-tree implementation.

This is provided as a convenience to help you test your code. It should not be
changed or submitted to the autograder.

"""

import numpy as np
from typing import Union, Optional
from dataclasses import dataclass


@dataclass(init=True)
class KDInternalNode:
    """An internal node in a k-d tree."""
    
    # the left and right children, which are either KDInternalNodes or
    # leaf nodes (ndarrays)
    left: Union['KDInternalNode', np.ndarray]
    right: Union['KDInternalNode', np.ndarray]
        
    # the question's threshold and the dimension it refers to
    # Given an array representing a point, this asks:
    # is point[dimension] >= threshold?
    threshold: float
    dimension: int
        
    def __repr__(self):
        return f'KDInternalNode(dimension={self.dimension}, threshold={self.threshold})'


def build_kd_tree(data, m=5):
    """Construct a k-d tree from data.
    
    Parameters
    ----------
    data : ndarray
        An n x d array of n points in d dimensional space.
    m : int
        The max leaf node size. Default: 5
        
    Returns
    -------
    KDInternalNode or ndarray
        The root node of the k-d tree. If the number of the points in
        the tree is <5, returns the input ndarray.
    """
    if len(data) <= m:
        return data.copy()
    
    # find the dimension with greatest spread
    spread = data.max(axis=0) - data.min(axis=0)
    splitting_dimension = np.argmax(spread)
    
    # partition the data in-place around the median
    sort_ix = np.argpartition(data[:, splitting_dimension], len(data) // 2)
    data[:] = data[sort_ix]
    threshold = data[len(data) // 2, splitting_dimension]
    
    left_data, right_data = np.split(data, [len(data) // 2])
    
    left = build_kd_tree(left_data, m=m)
    right = build_kd_tree(right_data, m=m)
    
    return KDInternalNode(left=left, right=right, threshold=threshold, dimension=splitting_dimension)
