"""Starter code for timing problem.

This problem is *not autograded*, so there is autograder to submit this code to.
Instead, you should turn in your code for the below three functions as an image
or text to the normal Gradescope assignment.

"""
import numpy as np

def experiment_array(n, k):
    ...

def experiment_heap(n, k):
    ...

def experiment_treap(n, k):
    ...

# OnlineMedian
# ------------
# you should not include this code in your submission; it's just here for
# convenience

def parent(ix):
    return (ix - 1) // 2

def left_child(ix):
    return 2*ix + 1

def right_child(ix):
    return 2*ix + 2

class MaxHeap:
    
    def __init__(self, keys=None):
        if keys is None:
            keys = []
        self.keys = keys
        
    def max(self):
        return self.keys[0]
    
    def _swap(self, i, j):
        self.keys[i], self.keys[j] = self.keys[j], self.keys[i]
    
    def increase_key(self, ix, key):
        if key < self.keys[ix]:
            raise ValueError('New key is smaller.')
            
        self.keys[ix] = key
        while parent(ix) >= 0 and self.keys[parent(ix)] < key:
            self._swap(ix, parent(ix))
            ix = parent(ix)
            
    def insert(self, key):
        self.keys.append(key)
        self.increase_key(len(self.keys)-1, key)
        
    def pop_max(self):
        if len(self.keys) == 0:
            raise IndexError('Heap is empty.')
        highest = self.max()
        self.keys[0] = self.keys[-1]
        self.keys.pop()
        self._push_down(0)
        return highest

    def _push_down(self, i):
        left = left_child(i)
        right = right_child(i)
        if left < len(self.keys) and self.keys[left] > self.keys[i]:
            largest = left
        else:
            largest = i
        
        if right < len(self.keys) and self.keys[right] > self.keys[largest]:
            largest = right
            
        if largest != i:
            self._swap(i, largest)
            self._push_down(largest)

    def __len__(self):
        return len(self.keys)


class MinHeap:

    def __init__(self, keys=None):
        self._max_heap = MaxHeap(keys)

    def __len__(self):
        return len(self._max_heap)

    def min(self):
        return -self._max_heap.max()

    def _get_key(self, ix):
        return -self._max_heap.keys[ix]

    def decrease_key(self, ix, key):
        if key > self._get_key(ix):
            raise ValueError('New key is larger.')

        self._max_heap.increase_key(ix, -key)

    def insert(self, key):
        self._max_heap.insert(-key)

    def pop_min(self):
        return -self._max_heap.pop_max()

class OnlineMedian:

    def __init__(self):
        self._upper = MinHeap()
        self._lower = MaxHeap()
        self._empty = True

    def insert(self, key):
        """Insert a key into the collection."""
        if self._upper:
            if key >= self._upper.min():
                self._upper.insert(key)
            else:
                self._lower.insert(key)
        else:
            self._lower.insert(key)

        if len(self._lower) - len(self._upper) >= 2:
            self._rebalance(self._upper, self._lower)
        elif len(self._upper) - len(self._lower) >= 2:
            self._rebalance(self._lower, self._upper)

        self._empty = False

    def median(self):
        """Return a median of the collection.

        If the collection is empty, returns nan.

        Example
        -------

        >>> om = OnlineMedian()
        >>> om.median()
        nan
        >>> om.insert(30)
        >>> om.insert(10)
        >>> om.insert(-20)
        >>> om.median()
        10

        """
        if self._empty:
            return float('nan')

        if len(self._lower) == len(self._upper):
            return self._lower.max()
        elif len(self._upper) > len(self._lower):
            return self._upper.min()
        else:
            return self._lower.max()

    def _rebalance(self, smaller, larger):

        def pop(container):
            if isinstance(container, MinHeap):
                return container.pop_min()
            else:
                return container.pop_max()

        while len(larger) - len(smaller) >= 2:
            x = pop(larger)
            smaller.insert(x)
