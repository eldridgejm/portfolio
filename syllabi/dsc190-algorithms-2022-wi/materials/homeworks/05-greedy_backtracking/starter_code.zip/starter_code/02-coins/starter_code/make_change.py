# the value of a quarter, dime, nickel, penny
VALUES = (25, 10, 5, 1)


def make_change(t: int):
    """Count the number of ways to make change.

    Assumes an unlimited number of quarters, dimes, nickels, pennies.

    Parameters
    ----------
    t: int
        The total number of cents.

    Example
    -------
    >>> make_change(5) # 5 pennies or 1 nickel
    2
    >>> # (1 dime + 1 penny) or (2 nickels + 1 penny) or (11 pennies)
    >>> # or (6 pennies + 1 nickel)
    >>> make_change(11)
    4

    """
    ...
