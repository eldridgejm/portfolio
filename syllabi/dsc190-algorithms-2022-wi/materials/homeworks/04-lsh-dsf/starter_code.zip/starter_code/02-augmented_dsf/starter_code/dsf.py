class DisjointSetForest:

    def __init__(self):
        ...

    def make_set(self):
        """Create a new singleton set.

        Returns
        -------
        int
            The id of the element that was just inserted.

        Example
        -------
        >>> dsf = DisjointSetForest()
        >>> dsf.make_set()
        0
        >>> dsf.make_set()
        1
        """
        ...

    def find_set(self, x):
        """Find the representative of the element.

        Parameters
        ----------
        x : int
            The element to look for.

        Returns
        -------
        int
            The representative of the set containing `x`. The representative
            of a set with more than one element is arbitrary, but it should be
            the same of all elements of the set.

        Raises
        ----
        ValueError
            If `x` is not in the collection.

        Examples
        --------
        >>> dsf = DisjointSetForest()
        >>> dsf.make_set()
        0
        >>> dsf.find_set(0) == 0
        True
        >>> dsf.find_set(99)
        Traceback (most recent call last):
        ValueError: 99 is not in the collection.

        """
        try:
            parent = self._parent[x]
        except IndexError:
            raise ValueError(f'{x} is not in the collection.')

        if self._parent[x] is None:
            return x
        else:
            root = self.find_set(self._parent[x])
            self._parent[x] = root
            return root

    def union(self, x, y):
        """Union the sets containing x and y, in-place.

        Parameters
        ----------
        x, y : int
            The elements whose sets should be unioned. They do not need
            to belong to different sets.

        Raises
        ------
        ValueError
            If x or y are not in the collection.

        Example
        -------
        >>> dsf = DisjointSetForest()
        >>> dsf.make_set()
        0
        >>> dsf.make_set()
        1
        >>> dsf.number_of_sets
        2
        >>> dsf.union(0, 1)
        >>> dsf.number_of_sets
        1
        >>> dsf.find_set(0) == dsf.find_set(1)
        True

        """
        ...

    def size_of_set(self, x):
        """The size of the set containing x.

        Parameters
        ----------
        x : int
            The element whose set will be sized.

        Returns
        -------
        int
            The size of the set containing x.

        Raises
        ------
        ValueError
            If x is not in the collection.

        Example
        -------
        >>> dsf = DisjointSetForest()
        >>> dsf.make_set()
        0
        >>> dsf.make_set()
        1
        >>> dsf.union(0, 1)
        >>> dsf.size_of_set(0)
        2

        """
        ...
